
<?php
/*
$config['useragent'] = 'CodeIgniter';
$config['protocol'] = 'pop3';
//$config['mailpath'] = '/usr/sbin/sendmail';
$config['smtp_crypto'] = 'ssl';
$config['smtp_host'] = 'eskaygroup.net';
$config['smtp_user'] = 'challan@eskaygroup.net';
$config['smtp_pass'] = '5y#5Cvg5ofqHStrd';
$config['smtp_port'] = 25; */

$config['useragent'] = 'CodeIgniter';
//$config['protocol'] = 'smtp';
//$config['mailpath'] = '/usr/sbin/sendmail';
//$config['smtp_crypto'] = 'ssl';
$config['smtp_host'] = 'ssl://smtp.gmail.com';
$config['smtp_user'] = 'surajit@infotechsystems.in';
$config['smtp_pass'] = 'admin@1234#';
$config['smtp_port'] = 465; 
$config['smtp_timeout'] = 5;
$config['wordwrap'] = TRUE;
$config['wrapchars'] = 76;
$config['mailtype'] = 'html';
$config['charset'] = 'utf-8';
$config['validate'] = FALSE;
$config['priority'] = 3;
$config['crlf'] = "\r\n";
$config['newline'] = "\r\n";
$config['bcc_batch_mode'] = FALSE;
$config['bcc_batch_size'] = 200;
$config['charset'] = 'iso-8859-1';
$config['wordwrap'] = TRUE;

?>