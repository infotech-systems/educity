<div class="header-breadcrumbs">
        <div class="container">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <div class="breadcrumbs-title text-center">
                <h2><?php echo $page->page_name; ?></h2>
                <div class="subheader-pages">
                  <ul>
                    <li>Home</li>
                    <li><?php echo $page->page_name; ?></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- header breadcrumbs end Here -->
      <!-- aboutus-video area start Here -->
      <div class="aboutus-video">
        <div class="container">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <div class="about-content" id="bullet">
                <h3><?php echo $page->page_name; ?></h3>
                <p><?php echo $page->page_content; ?></p>
                
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- aboutus-video area end Here -->
     