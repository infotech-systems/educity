<?php
class SM_Controller extends CI_Controller
{
	
}